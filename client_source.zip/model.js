

function Orden(mesa) {

    //tupla PLATOxCANTIDAD
    this.orderAmountsMap={};

    this.tableNumber = mesa;
}

/**
 * @obj Agrega el plato a la orden.
 * @pre plato es el NOMBRE del plato
 * @pos si la orden ya tiene un plato, se incrementa en uno
 *      la cantidad del mismo. De lo contrario, lo agrega con
 *      un valor de 1.
 */
Orden.prototype.agregarPlato=function(plato){

    //implementar
   
};


$(document).ready(
        function () {
                        

        }
);
